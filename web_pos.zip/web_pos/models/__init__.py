from . import hr_mail
from . import pos_inherit
from . import pos_setiing
# from . import reciept
from . import pos_config
from . import location
from . import custom_contact